const {connectMongoDb} = require("./connectMongoDb.js");

module.exports = {
    connectMongoDb: connectMongoDb,
}
