const installServerConfigs = require("./server.js");

module.exports = {
    installServerConfigs
}